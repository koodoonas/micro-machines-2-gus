# Repository setup

Name: micro-machines-2-gus

Description: Gravis Ultrasound hardware mixing for Micro Machines 2 DOS: music and SFX, DMA sample uploads, and a fix for the audio timer slowdown.

Suggested first commit: Add Micro Machines 2 GUS hardware audio patch 1.0
Suggested release tag: v1.0
Suggested release title: Micro Machines 2 GUS hardware audio patch 1.0
Release body: docs/RELEASE-1.0.md

Commit and release publishing are pending the project owner's command.
